# ClearBank Backend Module — Auth + Admin + Emails

Ce zip contient SEULEMENT les fichiers backend à ajouter à ton projet ClearBank existant.
**NE REMPLACE PAS** ton projet entier — copie juste ces fichiers dans ton dossier.

---

## 📦 Fichiers inclus

```
src/lib/supabase.js              → Config Supabase
src/contexts/AuthContext.jsx     → Auth global (login/signup/signout)
src/pages/Login.jsx              → Page login / inscription
src/pages/Dashboard.jsx          → Dashboard client
src/pages/Admin.jsx              → Dashboard admin (voir leads, valider, envoyer emails)
src/components/ContactForm.jsx   → Formulaire de contact avec email auto
supabase/functions/send-email/   → Edge Function pour envoyer les emails
supabase/config.toml             → Config Supabase
.env.example                     → Exemple de variables d'environnement
```

---

## 🚀 Étape 1 — Copier les fichiers

Copie le contenu de ce zip dans ton projet existant (par-dessus, sans écraser tes fichiers) :

```bash
# Copie les dossiers
cp -r src/lib/supabase.js           ton-projet/src/lib/
cp -r src/contexts/                  ton-projet/src/
cp -r src/pages/Login.jsx            ton-projet/src/pages/
cp -r src/pages/Dashboard.jsx        ton-projet/src/pages/
cp -r src/pages/Admin.jsx            ton-projet/src/pages/
cp -r src/components/ContactForm.jsx ton-projet/src/components/
cp -r supabase/                      ton-projet/
cp .env.example                      ton-projet/
```

---

## 🚀 Étape 2 — Installer la dépendance Supabase

```bash
npm install @supabase/supabase-js
```

---

## 🚀 Étape 3 — Modifier ton App.jsx existant

Ouvre ton `src/App.jsx` et ajoute :

### 1. Importe AuthProvider et les nouvelles pages

```jsx
import { AuthProvider } from "@/contexts/AuthContext"
import { Login } from "@/pages/Login"
import { Dashboard } from "@/pages/Dashboard"
import { Admin } from "@/pages/Admin"
```

### 2. Enveloppe ton app avec AuthProvider

```jsx
// AVANT :
<BrowserRouter>
  <Routes>...</Routes>
</BrowserRouter>

// APRÈS :
<BrowserRouter>
  <AuthProvider>
    <Routes>
      {/* tes routes existantes */}
      <Route path="/login" element={<Login />} />
      <Route path="/dashboard" element={<Dashboard />} />
      <Route path="/admin" element={<Admin />} />
    </Routes>
  </AuthProvider>
</BrowserRouter>
```

### Exemple complet de App.jsx modifié :

```jsx
import { BrowserRouter, Routes, Route } from "react-router-dom"
import { AuthProvider } from "@/contexts/AuthContext"

// Tes pages existantes
import { Home } from "@/pages/Home"
import { InteriorPage } from "@/components/InteriorPage"

// Nouvelles pages backend
import { Login } from "@/pages/Login"
import { Dashboard } from "@/pages/Dashboard"
import { Admin } from "@/pages/Admin"

// Tes composants existants
import { Navbar } from "@/components/Navbar"
import { Footer } from "@/components/Footer"

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/:category/:slug" element={<InteriorPage />} />
          <Route path="/:category" element={<InteriorPage />} />

          {/* NOUVELLES ROUTES */}
          <Route path="/login" element={<Login />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/admin" element={<Admin />} />
        </Routes>
        <Footer />
      </AuthProvider>
    </BrowserRouter>
  )
}
```

---

## 🚀 Étape 4 — Modifier ta Navbar existante

Dans ton `src/components/Navbar.jsx`, ajoute le bouton login/admin :

```jsx
import { useAuth } from "@/contexts/AuthContext"
import { Link } from "react-router-dom"
import { User, LogOut, Shield } from "lucide-react"

// Dans ton composant Navbar :
const { user, signOut, isAdmin } = useAuth()

// Dans le JSX, ajoute ça dans la partie droite de ta navbar :
{user ? (
  <div className="flex items-center gap-3">
    {isAdmin && (
      <Link to="/admin" className="text-teal text-sm border border-teal/20 px-3 py-1 rounded-full">
        Admin
      </Link>
    )}
    <Link to="/dashboard" className="text-white/80 text-sm">
      <User className="w-4 h-4 inline" /> Account
    </Link>
    <button onClick={signOut} className="text-white/40 text-sm">
      <LogOut className="w-4 h-4" />
    </button>
  </div>
) : (
  <Link to="/login" className="text-white/80 text-sm">
    <User className="w-4 h-4 inline" /> Sign in
  </Link>
)}
```

---

## 🚀 Étape 5 — Créer les tables Supabase

Va dans Supabase → SQL Editor, exécute :

```sql
create table contacts (
  id uuid default gen_random_uuid() primary key,
  name text not null,
  email text not null,
  company text,
  message text not null,
  status text default 'pending',
  advisor_name text default 'M. Chevalier',
  advisor_email text default 'm.chevalier@clear-bk.com',
  created_at timestamp with time zone default now()
);

create table profiles (
  id uuid references auth.users on delete cascade primary key,
  full_name text,
  company text,
  role text default 'client',
  created_at timestamp with time zone default now()
);

alter table contacts enable row level security;
alter table profiles enable row level security;

create policy "Anyone can insert contacts" on contacts for insert to anon with check (true);
create policy "Admin can view contacts" on contacts for select to authenticated using (auth.uid() in (select id from profiles where role = 'admin'));
create policy "Admin can update contacts" on contacts for update to authenticated using (auth.uid() in (select id from profiles where role = 'admin'));
create policy "Users can view own profile" on profiles for select to authenticated using (auth.uid() = id);
create policy "Users can update own profile" on profiles for update to authenticated using (auth.uid() = id);
```

---

## 🚀 Étape 6 — Configurer Resend (emails)

1. Va sur [resend.com](https://resend.com) → crée un compte
2. Vérifie ton domaine `clear-bk.com`
3. Récupère ta clé API

---

## 🚀 Étape 7 — Déployer l'Edge Function

```bash
# Dans ton terminal, à la racine du projet
supabase login
supabase secrets set RESEND_API_KEY=re_xxxxxxxx
supabase functions deploy send-email
```

---

## 🚀 Étape 8 — Créer le fichier .env

Crée un fichier `.env` à la racine de ton projet :

```env
VITE_SUPABASE_URL=https://xxxxx.supabase.co
VITE_SUPABASE_ANON_KEY=eyJ...
RESEND_API_KEY=re_xxxxxxxx
```

---

## 🚀 Étape 9 — Build & Deploy

```bash
npm install
npm run build
# Déploie sur Vercel/Netlify comme d'habitude
```

---

## 🚀 Étape 10 — Créer ton compte admin

1. Va sur `/login` de ton site → inscris-toi
2. Dans Supabase → Table Editor → `profiles`
3. Change ton `role` de `'client'` à `'admin'`
4. Reconnecte-toi → le lien **Admin** apparaît

---

## 📧 Logique des emails

| Étape | Action | Email envoyé |
|-------|--------|--------------|
| 1 | Client remplit le formulaire | **Confirmation** : "Merci pour votre demande" |
| 2 | Admin clique "Valider" | **Activation** : "Votre compte est validé" |

---

## ⚠️ Important

- **NE remplace PAS** tes fichiers existants (Navbar, Footer, Home, etc.)
- **Ajoute juste** les nouvelles routes dans App.jsx
- **Ajoute juste** le bouton login dans ta Navbar existante
- Le design de ton site reste **identique**
