import { serve } from "https://deno.land/std@0.168.0/http/server.ts"

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")

const emailTemplate = (type, data) => {
  const logoUrl = "https://clear-bk.com/logo-clearbank.png"

  if (type === "confirmation") {
    return `
    <!DOCTYPE html>
    <html>
    <head><meta charset="utf-8"></head>
    <body style="margin:0;padding:0;background:#f5f5f5;font-family:Arial,sans-serif;">
      <table width="100%" cellpadding="0" cellspacing="0">
        <tr>
          <td align="center" style="padding:40px 20px;">
            <table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,0.08);">
              <tr>
                <td style="background:#0a0a0a;padding:30px 40px;text-align:center;">
                  <img src="${logoUrl}" alt="ClearBank" style="height:40px;" />
                </td>
              </tr>
              <tr>
                <td style="padding:40px;">
                  <h1 style="color:#0a0a0a;font-size:24px;margin:0 0 20px;">Merci pour votre demande, ${data.name}</h1>
                  <p style="color:#555;font-size:16px;line-height:1.6;margin:0 0 20px;">
                    Nous avons bien reçu votre demande d'ouverture de compte. Notre équipe l'examine actuellement.
                  </p>
                  <div style="background:#f8f9fa;border-left:4px solid #70F1DA;padding:20px;margin:20px 0;">
                    <p style="margin:0;color:#333;font-size:14px;"><strong>Nom :</strong> ${data.name}</p>
                    <p style="margin:5px 0 0;color:#333;font-size:14px;"><strong>Email :</strong> ${data.email}</p>
                    <p style="margin:5px 0 0;color:#333;font-size:14px;"><strong>Entreprise :</strong> ${data.company || "Non renseignée"}</p>
                  </div>
                  <p style="color:#555;font-size:16px;line-height:1.6;margin:20px 0 0;">
                    Vous recevrez un email de confirmation dès que votre conseiller aura validé votre dossier.
                  </p>
                </td>
              </tr>
              <tr>
                <td style="background:#0a0a0a;padding:30px 40px;text-align:center;">
                  <p style="color:#70F1DA;margin:0;font-size:14px;font-weight:600;">ClearBank</p>
                  <p style="color:#888;margin:8px 0 0;font-size:12px;">
                    ${data.advisor_name}<br>
                    Conseiller Clientèle<br>
                    <a href="mailto:${data.advisor_email}" style="color:#70F1DA;">${data.advisor_email}</a>
                  </p>
                  <p style="color:#555;margin:20px 0 0;font-size:11px;">
                    ClearBank Limited, Level 27, The Broadgate Tower, London EC2A 2EW
                  </p>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </body>
    </html>`
  }

  if (type === "validation") {
    return `
    <!DOCTYPE html>
    <html>
    <head><meta charset="utf-8"></head>
    <body style="margin:0;padding:0;background:#f5f5f5;font-family:Arial,sans-serif;">
      <table width="100%" cellpadding="0" cellspacing="0">
        <tr>
          <td align="center" style="padding:40px 20px;">
            <table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,0.08);">
              <tr>
                <td style="background:#0a0a0a;padding:30px 40px;text-align:center;">
                  <img src="${logoUrl}" alt="ClearBank" style="height:40px;" />
                </td>
              </tr>
              <tr>
                <td style="padding:40px;">
                  <h1 style="color:#0a0a0a;font-size:24px;margin:0 0 20px;">Votre compte est validé, ${data.name}</h1>
                  <p style="color:#555;font-size:16px;line-height:1.6;margin:0 0 20px;">
                    Félicitations ! Votre conseiller <strong>${data.advisor_name}</strong> a validé votre demande.
                  </p>
                  <div style="background:#e8f5f3;border:1px solid #70F1DA;border-radius:8px;padding:24px;margin:24px 0;text-align:center;">
                    <p style="color:#0a0a0a;font-size:16px;margin:0 0 16px;font-weight:600;">Prochaine étape : activez votre profil</p>
                    <a href="${data.activation_link}" style="display:inline-block;background:#0a0a0a;color:#70F1DA;text-decoration:none;padding:14px 32px;border-radius:50px;font-weight:600;font-size:14px;">ACTIVER MON COMPTE</a>
                  </div>
                  <div style="background:#fff8e6;border-left:4px solid #f0a500;padding:20px;margin:20px 0;">
                    <p style="margin:0;color:#333;font-size:14px;"><strong>📄 Convention bancaire</strong></p>
                    <p style="margin:8px 0 0;color:#555;font-size:13px;line-height:1.5;">
                      Veuillez télécharger, signer et nous retourner la convention pour finaliser l'ouverture de votre compte.
                    </p>
                  </div>
                </td>
              </tr>
              <tr>
                <td style="background:#0a0a0a;padding:30px 40px;text-align:center;">
                  <p style="color:#70F1DA;margin:0;font-size:14px;font-weight:600;">ClearBank</p>
                  <p style="color:#888;margin:8px 0 0;font-size:12px;">
                    ${data.advisor_name}<br>
                    Conseiller Clientèle<br>
                    <a href="mailto:${data.advisor_email}" style="color:#70F1DA;">${data.advisor_email}</a>
                  </p>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </body>
    </html>`
  }
}

serve(async (req) => {
  if (req.method !== "POST") {
    return new Response("Method not allowed", { status: 405 })
  }

  try {
    const { to, type, data } = await req.json()

    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: `${data.advisor_name || "ClearBank"} <${data.advisor_email || "contact@clear-bk.com"}>`,
        to: [to],
        subject: type === "confirmation" 
          ? "ClearBank — Confirmation de votre demande" 
          : "ClearBank — Votre compte est validé, activez votre profil",
        html: emailTemplate(type, data),
      }),
    })

    if (!res.ok) {
      const error = await res.text()
      throw new Error(error)
    }

    const result = await res.json()
    return new Response(JSON.stringify(result), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    })
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    })
  }
})
