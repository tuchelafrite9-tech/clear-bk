import { useState } from "react"
import { supabase } from "@/lib/supabase"
import { Send, CheckCircle } from "lucide-react"

export function ContactForm() {
  const [form, setForm] = useState({ name: "", email: "", company: "", message: "" })
  const [sent, setSent] = useState(false)
  const [sending, setSending] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setSending(true)

    try {
      const { error: dbError } = await supabase.from("contacts").insert([{
        name: form.name,
        email: form.email,
        company: form.company,
        message: form.message,
        status: "pending",
        advisor_name: "M. Chevalier",
        advisor_email: "m.chevalier@clear-bk.com"
      }])

      if (dbError) throw dbError

      try {
        await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/send-email`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            to: form.email,
            type: "confirmation",
            data: {
              name: form.name,
              email: form.email,
              company: form.company,
              advisor_name: "M. Chevalier",
              advisor_email: "m.chevalier@clear-bk.com"
            }
          })
        })
      } catch (emailErr) {
        console.log("Email not sent (Edge Function may not be deployed yet)", emailErr)
      }

      setSent(true)
      setForm({ name: "", email: "", company: "", message: "" })
    } catch (err) {
      alert("Error: " + err.message)
    } finally {
      setSending(false)
    }
  }

  if (sent) {
    return (
      <div className="text-center py-12">
        <CheckCircle className="w-12 h-12 text-teal mx-auto mb-4" />
        <h3 className="text-xl font-semibold text-white">Message sent!</h3>
        <p className="text-white/50 mt-2">You will receive a confirmation email. Our advisor M. Chevalier will get back to you within 24 hours.</p>
        <button onClick={() => setSent(false)} className="mt-6 text-teal hover:underline text-sm">Send another message</button>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div className="grid sm:grid-cols-2 gap-5">
        <div>
          <label className="block text-sm text-white/60 mb-1.5">Full name</label>
          <input type="text" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
            className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-white/30 focus:outline-none focus:border-teal/50 transition-colors"
            placeholder="John Doe" />
        </div>
        <div>
          <label className="block text-sm text-white/60 mb-1.5">Email</label>
          <input type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })}
            className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-white/30 focus:outline-none focus:border-teal/50 transition-colors"
            placeholder="john@company.com" />
        </div>
      </div>
      <div>
        <label className="block text-sm text-white/60 mb-1.5">Company</label>
        <input type="text" value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })}
          className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-white/30 focus:outline-none focus:border-teal/50 transition-colors"
          placeholder="Acme Inc." />
      </div>
      <div>
        <label className="block text-sm text-white/60 mb-1.5">Message</label>
        <textarea required rows={5} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })}
          className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-white/30 focus:outline-none focus:border-teal/50 transition-colors resize-none"
          placeholder="Tell us about your project..." />
      </div>
      <button type="submit" disabled={sending}
        className="w-full sm:w-auto px-8 py-3 bg-teal text-[#0a0a0a] font-semibold rounded-full hover:bg-teal/90 disabled:opacity-50 transition-colors">
        {sending ? "Sending..." : <>Send message <Send className="w-4 h-4 ml-2 inline" /></>}
      </button>
    </form>
  )
}
