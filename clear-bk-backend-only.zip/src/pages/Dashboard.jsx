import { useEffect } from "react"
import { useNavigate } from "react-router-dom"
import { useAuth } from "@/contexts/AuthContext"
import { LogOut, User, Building, Shield } from "lucide-react"

export function Dashboard() {
  const { user, profile, signOut, loading } = useAuth()
  const navigate = useNavigate()

  useEffect(() => {
    if (!loading && !user) navigate("/login")
  }, [user, loading, navigate])

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-teal border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  if (!user) return null

  return (
    <div className="min-h-screen bg-[#0a0a0a] pt-24 pb-16">
      <div className="mx-auto max-w-[1400px] px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-12">
          <div>
            <h1 className="text-3xl font-heading font-bold text-white">My Account</h1>
            <p className="text-white/50 mt-1">Manage your ClearBank partner profile</p>
          </div>
          <button onClick={signOut} className="flex items-center gap-2 px-4 py-2 border border-white/20 text-white rounded-lg hover:bg-white/5 transition-colors">
            <LogOut className="w-4 h-4" /> Sign out
          </button>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="md:col-span-2 p-6 rounded-xl bg-white/[0.02] border border-white/5">
            <h2 className="text-lg font-semibold text-white mb-6">Profile</h2>
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-teal/10 flex items-center justify-center">
                  <User className="w-6 h-6 text-teal" />
                </div>
                <div>
                  <p className="text-white font-medium">{profile?.full_name || "Not set"}</p>
                  <p className="text-white/40 text-sm">{user.email}</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-teal/10 flex items-center justify-center">
                  <Building className="w-6 h-6 text-teal" />
                </div>
                <div>
                  <p className="text-white font-medium">{profile?.company || "Not set"}</p>
                  <p className="text-white/40 text-sm">Company</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-teal/10 flex items-center justify-center">
                  <Shield className="w-6 h-6 text-teal" />
                </div>
                <div>
                  <p className="text-white font-medium capitalize">{profile?.role || "Client"}</p>
                  <p className="text-white/40 text-sm">Account type</p>
                </div>
              </div>
            </div>
          </div>
          <div className="p-6 rounded-xl bg-white/[0.02] border border-white/5">
            <h2 className="text-lg font-semibold text-white mb-6">Quick Links</h2>
            <div className="space-y-3">
              <a href="#" className="block p-3 rounded-lg bg-white/5 hover:bg-white/[0.08] text-white/70 hover:text-white text-sm transition-colors">API Documentation</a>
              <a href="#" className="block p-3 rounded-lg bg-white/5 hover:bg-white/[0.08] text-white/70 hover:text-white text-sm transition-colors">Support Center</a>
              <a href="#" className="block p-3 rounded-lg bg-white/5 hover:bg-white/[0.08] text-white/70 hover:text-white text-sm transition-colors">Billing & Invoices</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
