import { useState } from "react"
import { Link, useNavigate } from "react-router-dom"
import { useAuth } from "@/contexts/AuthContext"
import { Eye, EyeOff, LogIn, UserPlus } from "lucide-react"

export function Login() {
  const [isSignUp, setIsSignUp] = useState(false)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [fullName, setFullName] = useState("")
  const [company, setCompany] = useState("")
  const [showPass, setShowPass] = useState(false)
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const { signIn, signUp } = useAuth()
  const navigate = useNavigate()

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError("")
    setLoading(true)

    if (isSignUp) {
      const { error } = await signUp(email, password, { full_name: fullName, company })
      if (error) setError(error.message)
      else {
        alert("Account created! Check your email to confirm, then log in.")
        setIsSignUp(false)
      }
    } else {
      const { error } = await signIn(email, password)
      if (error) setError(error.message)
      else navigate("/dashboard")
    }
    setLoading(false)
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-heading font-bold text-white">{isSignUp ? "Create account" : "Welcome back"}</h1>
          <p className="mt-2 text-white/50">{isSignUp ? "Join ClearBank" : "Sign in to your account"}</p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          {isSignUp && (
            <>
              <div>
                <label className="block text-sm text-white/60 mb-1.5">Full name</label>
                <input type="text" required value={fullName} onChange={(e) => setFullName(e.target.value)}
                  className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-white/30 focus:outline-none focus:border-teal/50" placeholder="John Doe" />
              </div>
              <div>
                <label className="block text-sm text-white/60 mb-1.5">Company</label>
                <input type="text" value={company} onChange={(e) => setCompany(e.target.value)}
                  className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-white/30 focus:outline-none focus:border-teal/50" placeholder="Acme Inc." />
              </div>
            </>
          )}
          <div>
            <label className="block text-sm text-white/60 mb-1.5">Email</label>
            <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-white/30 focus:outline-none focus:border-teal/50" placeholder="you@company.com" />
          </div>
          <div>
            <label className="block text-sm text-white/60 mb-1.5">Password</label>
            <div className="relative">
              <input type={showPass ? "text" : "password"} required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-white/30 focus:outline-none focus:border-teal/50 pr-12" placeholder="••••••••" />
              <button type="button" onClick={() => setShowPass(!showPass)} className="absolute right-3 top-1/2 -translate-y-1/2 text-white/40 hover:text-white">
                {showPass ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
          </div>
          {error && <p className="text-red-400 text-sm bg-red-400/10 px-4 py-2 rounded-lg">{error}</p>}
          <button type="submit" disabled={loading}
            className="w-full py-3 bg-teal text-[#0a0a0a] font-semibold rounded-full hover:bg-teal/90 disabled:opacity-50 transition-colors">
            {loading ? "Please wait..." : (
              <>{isSignUp ? <UserPlus className="w-4 h-4 mr-2 inline" /> : <LogIn className="w-4 h-4 mr-2 inline" />}{isSignUp ? "Create account" : "Sign in"}</>
            )}
          </button>
        </form>
        <p className="mt-6 text-center text-white/50 text-sm">
          {isSignUp ? "Already have an account?" : "Don't have an account?"}{" "}
          <button onClick={() => { setIsSignUp(!isSignUp); setError("") }} className="text-teal hover:underline font-medium">
            {isSignUp ? "Sign in" : "Create one"}
          </button>
        </p>
        <div className="mt-8 text-center">
          <Link to="/" className="text-white/30 hover:text-white/60 text-sm transition-colors">← Back to home</Link>
        </div>
      </div>
    </div>
  )
}
