import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom"
import { useAuth } from "@/contexts/AuthContext"
import { supabase } from "@/lib/supabase"
import { LogOut, Mail, User, Building, Calendar, Trash2, RefreshCw, CheckCircle, Send } from "lucide-react"

export function Admin() {
  const { user, signOut, isAdmin, loading } = useAuth()
  const navigate = useNavigate()
  const [contacts, setContacts] = useState([])
  const [loadingContacts, setLoadingContacts] = useState(true)
  const [sendingEmail, setSendingEmail] = useState(null)

  useEffect(() => {
    if (!loading && !user) navigate("/login")
    if (!loading && user && !isAdmin) navigate("/dashboard")
  }, [user, loading, isAdmin, navigate])

  useEffect(() => {
    if (isAdmin) fetchContacts()
  }, [isAdmin])

  async function fetchContacts() {
    setLoadingContacts(true)
    const { data, error } = await supabase.from("contacts").select("*").order("created_at", { ascending: false })
    if (!error) setContacts(data || [])
    setLoadingContacts(false)
  }

  async function deleteContact(id) {
    if (!confirm("Delete this contact?")) return
    await supabase.from("contacts").delete().eq("id", id)
    fetchContacts()
  }

  async function validateContact(contact) {
    if (!confirm(`Validate ${contact.name} and send activation email?`)) return
    setSendingEmail(contact.id)
    try {
      await supabase.from("contacts").update({ status: "validated" }).eq("id", contact.id)
      await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/send-email`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          to: contact.email,
          type: "validation",
          data: {
            name: contact.name,
            email: contact.email,
            company: contact.company,
            advisor_name: contact.advisor_name || "M. Chevalier",
            advisor_email: contact.advisor_email || "m.chevalier@clear-bk.com",
            activation_link: `${window.location.origin}/login`,
          },
        }),
      })
      alert(`✅ ${contact.name} validated and email sent!`)
      fetchContacts()
    } catch (err) {
      alert("Error: " + err.message)
    } finally {
      setSendingEmail(null)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-teal border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }
  if (!isAdmin) return null

  return (
    <div className="min-h-screen bg-[#0a0a0a] pt-24 pb-16">
      <div className="mx-auto max-w-[1400px] px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-10">
          <div>
            <h1 className="text-3xl font-heading font-bold text-white">Admin Dashboard</h1>
            <p className="text-white/50 mt-1">Manage leads and validate accounts</p>
          </div>
          <div className="flex gap-3">
            <button onClick={fetchContacts} className="flex items-center gap-2 px-4 py-2 border border-white/20 text-white rounded-lg hover:bg-white/5 transition-colors">
              <RefreshCw className="w-4 h-4" /> Refresh
            </button>
            <button onClick={signOut} className="flex items-center gap-2 px-4 py-2 border border-white/20 text-white rounded-lg hover:bg-white/5 transition-colors">
              <LogOut className="w-4 h-4" /> Sign out
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
          {[
            { label: "Total leads", value: contacts.length },
            { label: "Pending", value: contacts.filter(c => c.status === "pending").length },
            { label: "Validated", value: contacts.filter(c => c.status === "validated").length },
            { label: "This week", value: contacts.filter(c => { const d = new Date(c.created_at); const w = new Date(); w.setDate(w.getDate() - 7); return d > w }).length },
          ].map((stat, i) => (
            <div key={i} className="p-5 rounded-xl bg-white/[0.02] border border-white/5">
              <p className="text-2xl font-bold text-white">{stat.value}</p>
              <p className="text-sm text-white/40 mt-1">{stat.label}</p>
            </div>
          ))}
        </div>

        <div className="rounded-xl bg-white/[0.02] border border-white/5 overflow-hidden">
          <div className="px-6 py-4 border-b border-white/5 flex items-center justify-between">
            <h2 className="text-lg font-semibold text-white">All Contacts</h2>
            <span className="text-sm text-white/40">{contacts.length} total</span>
          </div>
          {loadingContacts ? (
            <div className="p-12 text-center"><div className="w-8 h-8 border-2 border-teal border-t-transparent rounded-full animate-spin mx-auto" /></div>
          ) : contacts.length === 0 ? (
            <div className="p-12 text-center">
              <Mail className="w-12 h-12 text-white/10 mx-auto mb-4" />
              <p className="text-white/50">No contacts yet</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-white/5">
                    <th className="text-left text-xs font-medium text-white/40 uppercase tracking-wider px-6 py-3">Status</th>
                    <th className="text-left text-xs font-medium text-white/40 uppercase tracking-wider px-6 py-3">Name</th>
                    <th className="text-left text-xs font-medium text-white/40 uppercase tracking-wider px-6 py-3">Email</th>
                    <th className="text-left text-xs font-medium text-white/40 uppercase tracking-wider px-6 py-3 hidden md:table-cell">Company</th>
                    <th className="text-left text-xs font-medium text-white/40 uppercase tracking-wider px-6 py-3">Date</th>
                    <th className="text-right text-xs font-medium text-white/40 uppercase tracking-wider px-6 py-3">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {contacts.map((contact) => (
                    <tr key={contact.id} className="border-b border-white/5 hover:bg-white/[0.02] transition-colors">
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${contact.status === "validated" ? "bg-green-500/10 text-green-400" : "bg-yellow-500/10 text-yellow-400"}`}>
                          {contact.status === "validated" ? <><CheckCircle className="w-3 h-3" /> Validated</> : "Pending"}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-teal/10 flex items-center justify-center shrink-0">
                            <User className="w-4 h-4 text-teal" />
                          </div>
                          <span className="text-white font-medium text-sm">{contact.name}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <a href={`mailto:${contact.email}`} className="text-teal text-sm hover:underline">{contact.email}</a>
                      </td>
                      <td className="px-6 py-4 hidden md:table-cell">
                        <div className="flex items-center gap-2 text-white/50 text-sm">
                          {contact.company && <Building className="w-3.5 h-3.5" />}
                          {contact.company || "—"}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2 text-white/30 text-xs">
                          <Calendar className="w-3.5 h-3.5" />
                          {new Date(contact.created_at).toLocaleDateString()}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          {contact.status !== "validated" && (
                            <button onClick={() => validateContact(contact)} disabled={sendingEmail === contact.id}
                              className="text-teal hover:text-teal/70 transition-colors p-1.5 rounded-lg hover:bg-teal/10 disabled:opacity-50" title="Validate & send email">
                              {sendingEmail === contact.id ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                            </button>
                          )}
                          <button onClick={() => deleteContact(contact.id)} className="text-white/20 hover:text-red-400 transition-colors p-1.5" title="Delete">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
